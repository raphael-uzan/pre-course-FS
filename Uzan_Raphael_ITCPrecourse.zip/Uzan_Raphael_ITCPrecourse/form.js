
// Footer //

const footerWords = ["HTML", "CSS", "JavaScript"];
let footerSentence = document.querySelector('.sentence');

footerSentence.innerText = `This page was built using: ${footerWords[0]}, ${footerWords[1]} and ${footerWords[2]}`





// Contact page //

let inputFirstName = document.getElementById("firstname");
let genderSelected = document.getElementById("gender");
let inputLastName = document.getElementById("lastname");
let inputEmail = document.getElementById("email");
let inputComment = document.getElementById("comment");

let firstname = "firstname";
let gender = "gender";
let lastName = "lastname";
let email = "email";
let comment = "comment";

let submitButton = document.querySelector('.submit-button');



// Events //

inputFirstName.addEventListener('change', function() {
  firstname = inputFirstName.value;
  submitButton.classList.remove("disabled-1");
});

inputLastName.addEventListener('change', function() {
  lastName = inputLastName.value;
});

genderSelected.addEventListener('change', function() {
  gender = genderSelected.value;
  if (gender !== "Select value"){
    submitButton.classList.remove("disabled-2");
  }
});

inputEmail.addEventListener("change", function() {
  email  = inputEmail.value;
  submitButton.classList.remove("disabled-3");
});

inputComment.addEventListener("change", function() {
  comment  = inputComment.value;
  submitButton.classList.remove("disabled-4");
});




// Submit Button //

submitButton.addEventListener('click',function(){
  console.log(`Firstname: ${firstname}, Last Name: ${lastName}, Email: ${email}, Comment: ${comment}, Gender: ${gender}`)
});